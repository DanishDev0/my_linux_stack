# Salam

A humble script to get any Debian or Ubuntu-based Linux distro up and ready for my use. It installs LAMP, Python, and NodeJS for me along with other useful packages and utilities.
